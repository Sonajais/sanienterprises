// import ui from './module2.mjs'
// console.log(ui);

import dza, {a,b,c} from './module2.mjs'
console.log(dza);
console.log(c);
console.log(b);
console.log(a); //a1 con't write bcoz it is not bydefault
