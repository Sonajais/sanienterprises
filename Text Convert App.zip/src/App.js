import './App.css';
import Navbar from './components/Navbar';
import TextForm from './components/TextForm';
// let name="Sona";
function App() {
  return (
    <>
       {/* <Navbar/> */}
        {/* <Navbar title="SSS" aboutText="About SSS"/> */}
        <Navbar title="SSS"/>
        <div className="container my-3">
        <TextForm heading="Enter the text to analyze below"/>
        </div>
       
   {/* <div className="container">
    <h1>Hello {name}</h1>
   </div> */}
    </>
  );
}

export default App;
