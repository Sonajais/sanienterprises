import React, {useState} from 'react'
export default function TextForm(props) {
    //Upper Case
    const handleUpClick=()=>{
        // console.log("Uppercase was clicked:", + text);
        let newText=text.toUpperCase();
        setText(newText)
    }
    //Lower case
    const handleLoClick=()=>{
        // console.log("Lowercase was clicked", + text);
        let newText=text.toLowerCase();
        setText(newText)
    }
    //Clear Text
    const handleClearClick=()=>{
        let newText='';
        setText(newText)
    }
    // Copy case
    const handleCopyClick = () => {
        navigator.clipboard.writeText(text).then(() => {
        });
      }
      // Sentence Case
      const handleSentenceCaseClick = () => {
        let newText = text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
        setText(newText);
      }
       // Capitalized Case
      const handleCapitalizedCaseClick = () => {
        let newText = text.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
        setText(newText);
      }
      
// Alternating Case
      const handleAlternatingCaseClick = () => {
        let newText = '';
        for (let i = 0; i < text.length; i++) {
          if (i % 2 === 0) {
            newText += text[i].toUpperCase();
          } else {
            newText += text[i].toLowerCase();
          }
        }
        setText(newText);
      }
        
      // Title Case
const handleTitleCaseClick = () => {
    let newText = text.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
    setText(newText);
  }
  // Inverse Case
  const handleInverseCaseClick = () => {
    let newText = '';
    for (let i = 0; i < text.length; i++) {
      if (text[i] === text[i].toUpperCase()) {
        newText += text[i].toLowerCase();
      } else {
        newText += text[i].toUpperCase();
      }
    }
    setText(newText);
  }
  
// Download Text
const handleDownloadClick = () => {
    const element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', 'text.txt');
    element.style.display = 'none';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  }
  
    const handleOnChange=(event)=>{
        console.log("On Change");
        setText(event.target.value);
    }
    const [text, setText]=useState('');
    // setText("new text"); //correct way
    // text="new text"; //wrong eway to chsangre the state
  return (
    <>
    <div className="container">
    <h1>{props.heading}</h1>
        <div className="mb-3">
            <textarea className ="form-control" id="myBox" rows="8" value={text} onChange={handleOnChange}></textarea>
        </div>
        <button className="btn btn-primary mx-1 my-1" onClick={handleUpClick}>COVERT TO UPPERCASE</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleLoClick}>convert to lowercase</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleClearClick}>Clear Text</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleCopyClick}>Copy to Clipboard</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleSentenceCaseClick}>Sentence case</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleCapitalizedCaseClick }>Capitalized Case</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleAlternatingCaseClick}>aLtErNaTiNg cAsE</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleTitleCaseClick}>Title Case</button>
        <button className="btn btn-primary mx-1 my-1" onClick={handleInverseCaseClick}>InVeRsE CaSe</button>
        <button className="btn btn-primary mx-1 my-1" onClick={ handleDownloadClick}>Download Text</button>


    </div>
    <div className="container">
        <h1>Your text summary</h1>
        <p>{text.split(" ").length} words and {text.length} characters</p>
        <p>{0.008 * text.split(" ").length} Minutes read</p>
        <h2>Preview</h2>
        <p>{text}</p>
    </div>
 </>
)
}
