const a="Ankii";
const b="Nishu";
const c="Sona";
const d="Rinku";

export default d;
export {a};
export {b};
export {c};