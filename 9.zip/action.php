<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $uname=$_POST['uname'];
    $uname=$_POST['email'];
    $uname=$_POST['psw'];
    $conn= new mysqli('localhost','root','1st');

    if($con->connect_error){
        die('Connection Failed : '.$conn->connect_error);
    }
    else{
$stmt=$conn->prepare("insert into registration(uname,email,psw) values(?,?,?)");
  $stmt->bind_param("sss",$uname,$email,$psw);  
        $stmt->execute();
        echo "registration successfully...";
        $stmt->close();
        $stmt->close();
    }
    ?>
</body>
</html>