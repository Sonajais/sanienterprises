<!doctype html>
<html lang="en">

<head>
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
        integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="style.css" class="href">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>E-Commerce</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg data-bs-target">
            <div class="container-fluid">
                <a class="navbar-brand" href="#" style="margin-left:1rem; margin-right: 15rem;"><img src="img/logo.png"
                        height="50px"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.html"
                                style="color:white; font-weight: bolder; padding-left: 50px; padding-top: 20px;">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.html"
                                style="color:white; font-weight: bolder; padding-left: 30px; padding-top: 20px;">Contact
                                Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="login.html"><button
                                    class="bttn1">Login</button></a>
                        </li>&nbsp;&nbsp;&nbsp;
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="registration.html"><button
                                    class="bttn">Registration</button></a>
                        </li>
                </div>
            </div>
        </nav>
    </div>
    <br>
    <div class="container-fluid exb10">
        <div class="row">
            <div class="col-12 col-md-3">
                <img src="img/z1.png" class="rotate">
            </div>
            <div class="col-12 col-md-6 exb11">
                <img src="img/z2.png" class="rotate">
                <div class="row">
                    <div class="col col-md-6">
                        <button class="bttn4">Google</button>
                    </div>
                    <div class="col col-md-">
                        <button class="bttn5">Facebook</button>
                    </div>
                    <hr>
                    <p style="color:black;" class="text">Or</p>
                </div>
<?php
if(isset($_POST['uname']) && isset($_POST['email']) && isset($_POST['psw'])){
    echo "<h1>Form Submitted </h1>";
    echo "Your Username is" .$_POST['uname'] . "<br>";
    echo "Your Email-id is" .$_POST['email'] . "<br>";
    echo "Your Password is" .$_POST['psw'] . "<br>";
}
else{


?>

                <div class="text">Register</div>
                <form name="myForm" action="#" onsubmit="return validateForm()" method="POST">
                    <div class="form-row">
                        <div class="input-data">
                            <input type="text"  id="uname"  name="uname" required>
                            <div class="underline"></div>
                            <label for="">User Name</label>
                        </div>
                        
                    </div>
                    <div class="form-row">
                        <div class="input-data">
                            <input type="text" id="email" name="email" required>
                            <div class="underline"></div>
                            <label for="">Email</label>
                        </div>
                        
                    </div>
                    <div class="form-row">
                        <div class="input-data">
                            <input type="password" id="psw" name="psw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!,@,#,$,%,^,&,?]).{8,}" 
                            title="Must contain at least one number and one uppercase and one lowercase letter and one special character,
                             and at least 8 or more characters" required>
                            <div class="underline"></div>
                            <label for="">Password</label>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="input-data textarea">
                            <div class="form-row submit-btn">
                                <div class="input-data">
                                    <div class="inner"></div>
                                    <input type="submit" value="Register">
                                </div>
                            </div>
                        </div>
                    </div>
                    <p style="color:rgb(124, 122, 122);text-align: right;"> Already have an account? 
                        <a href="login.html" class="href ex8">Login</a></p>
                </form>
 <?php } ?>
                <img src="img/z3.png" style="margin-left:850px;" class="rotate">
                
            </div>
        </div>

    </div>

    <div id="message">
        <h3>Password must contain the following:</h3>
        <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
        <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
        <p id="number" class="invalid">A <b>number</b></p>
        <p id="special" class="invalid">A <b>number</b></p>
        <p id="length" class="invalid">Minimum <b>8 characters</b></p>
      </div>

    <div class="container-fluid exb8">
        <div class="row">
            <div class="col">
                <img src="img/logo.png" height="70px"><br><br>
                <p class="ex12">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sit odit ex laboriosam
                    veritatis.
                    Dolor sit optio maxime </p>
                Follow Us: &nbsp;&nbsp;&nbsp;&nbsp;
                <i class="fa-brands fa-facebook ex11"></i>&nbsp;
                <i class="fa-brands fa-square-instagram ex11"></i> &nbsp;
                <i class="fa-brands fa-square-twitter ex11"></i>&nbsp;
                <i class="fa-brands fa-linkedin ex11"></i>
            </div>
            <div class="col">
                <h3>Quick Link</h3><br>
                <a href="#" class="href ex10">About Us</a><br><br>
                <a href="#" class="href ex10">Features</a><br><br>
                <a href="#" class="href ex10">Feature Details</a><br><br>
                <a href="#" class="href ex10">Money Transfer</a><br><br>
            </div>
            <div class="col">
                <h3>Help Center</h3><br>
                <a href="#" class="href ex10">Contact Us</a><br><br>
                <a href="#" class="href ex10">Get Help</a><br><br>
                <a href="#" class="href ex10">Privacy Policy</a><br><br>
                <a href="#" class="href ex10">Terms & Conditions</a><br><br>
            </div>
            <div class="col ex12">
                <h3>Contact Info</h3>
                <p class="ex12"><i class="fa-solid fa-phone ex13"></i> Call Us: +(323) 750-1234<br>+(323) 750-1234<br><br>
                     <i class="fa-solid fa-address-book ex13"></i> Address: +7011 Vermont Ave, Los
                    Angeles, CA
                    90044
                <p class="ex12"><i class="fa-solid fa-envelope ex13"></i> Mail Us:
                    hello@appcubic.com<br>info@appcubic.com
                </p>
      
            </div>
        </div>
    </div>
    <div class="container-fluid exb9">
        <p>Copyright & design by @AppCubic - <b class="ex8">2023</b></p>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
        crossorigin="anonymous"></script>

        <!--password-->
        <script>
            var myInput = document.getElementById("psw");
            var letter = document.getElementById("letter");
            var capital = document.getElementById("capital");
            var number = document.getElementById("number");
            var number = document.getElementById("special");
            var length = document.getElementById("length");
            
            // When the user clicks on the password field, show the message box
            myInput.onfocus = function() {
              document.getElementById("message").style.display = "block";
            }
            
            // When the user clicks outside of the password field, hide the message box
            myInput.onblur = function() {
              document.getElementById("message").style.display = "none";
            }
            
            // When the user starts to type something inside the password field
            myInput.onkeyup = function() {
              // Validate lowercase letters
              var lowerCaseLetters = /[a-z]/g;
              if(myInput.value.match(lowerCaseLetters)) { 
                letter.classList.remove("invalid");
                letter.classList.add("valid");
              } else {
                letter.classList.remove("valid");
                letter.classList.add("invalid");
            }
            
              // Validate capital letters
              var upperCaseLetters = /[A-Z]/g;
              if(myInput.value.match(upperCaseLetters)) { 
                capital.classList.remove("invalid");
                capital.classList.add("valid");
              } else {
                capital.classList.remove("valid");
                capital.classList.add("invalid");
              }
            
              // Validate special
              var numbers = /[0-9]/g;
              if(myInput.value.match(numbers)) { 
                number.classList.remove("invalid");
                number.classList.add("valid");
              } else {
                number.classList.remove("valid");
                number.classList.add("invalid");
              }
              var numbers = /[!,@,#,$,%,^,&,?]/g;
              if(myInput.value.match(special)) { 
                number.classList.remove("invalid");
                number.classList.add("valid");
              } else {
                number.classList.remove("valid");
                number.classList.add("invalid");
              }
            
              // Validate length
              if(myInput.value.length >= 8) {
                length.classList.remove("invalid");
                length.classList.add("valid");
              } else {
                length.classList.remove("valid");
                length.classList.add("invalid");
              }
            }
            </script>
            <!--email-->
            
</body>

</html>