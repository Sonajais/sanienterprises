<?php
    // getting all values from the HTML form
    if(isset($_POST['submit']))
    {
        $uname = $_POST['uname'];
        $email= $_POST['email'];
        $psw = $_POST['psw'];
    }

    // database details
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "1st";

    // creating a connection
    $con = mysqli_connect($host, $username, $password, $dbname);

    // to ensure that the connection is made
    if (!$con)
    {
        die("Connection failed!" . mysqli_connect_error());
    }

    // using sql to create a data entry query
    $sql = "INSERT INTO registration (uname, email, psw) VALUES ('".$_POST['uname']."', '".$_POST['email']."', '".$_POST['psw']."')";
  
    // send query to the database to add values and confirm if successful
    $rs = mysqli_query($con, $sql);
    if($rs)
    {
        echo "Entries added!";
    }
  
    // close connection
    mysqli_close($con);

?>